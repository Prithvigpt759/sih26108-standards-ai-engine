# SIH 26108 — AI-Powered Indian Standards Recommendation Engine

Prototype backend for SIH 2026 Problem Statement 26108.

## What it does

- Procurement requirement analysis
- Requirement extraction
- Standards recommendation
- Primary/allied/testing/safety classification
- Standards relationship graph
- Current-status metadata
- Certification prompts
- Potential specification gaps
- Tender PDF/TXT analysis
- Tender Health Score
- Standards CRUD APIs
- OpenAPI/Swagger documentation

## Tech stack

Python 3.11+
FastAPI
SQLAlchemy
SQLite for the prototype
PyMuPDF for PDF extraction
Pydantic

The prototype intentionally uses a small, clearly marked demo dataset. Official BIS data should be loaded only from authorized/public sources and verified before real procurement use.

## Run on Windows PowerShell

```powershell
cd backend
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```

If PowerShell blocks activation, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Then activate again.

Open:
http://127.0.0.1:8000/docs

## Core endpoints

GET  /health
POST /api/analyze
GET  /api/analyses/{analysis_id}

GET  /api/standards
GET  /api/standards/{standard_id}
POST /api/standards
PUT  /api/standards/{standard_id}
DELETE /api/standards/{standard_id}

POST /api/tender/analyze
GET  /api/tender/{tender_analysis_id}

## Demo request

POST /api/analyze

```json
{
  "query": "We need 500 stainless steel water storage tanks of 5000 litre capacity for potable water use."
}
```

## Important

This is a hackathon prototype, not a legal/regulatory decision system. The backend returns a verification disclaimer. Do not claim that a demo record is an official BIS standard.
