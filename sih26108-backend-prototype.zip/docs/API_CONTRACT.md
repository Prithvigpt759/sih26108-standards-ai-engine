# Frontend ↔ Backend API Contract

## 1. Analyze procurement requirement

POST `/api/analyze`

Request:

```json
{
  "query": "5000 litre stainless steel potable water storage tank"
}
```

Response shape:

```json
{
  "analysis_id": 1,
  "requirements": {
    "product": "Water storage tank",
    "material": "stainless steel",
    "capacity": "5000 litre",
    "application": "Potable water",
    "quantity": null,
    "performance_requirements": [],
    "safety_requirements": [],
    "certification_requirements": [],
    "keywords": []
  },
  "recommendations": [],
  "allied_standards": [],
  "testing_standards": [],
  "safety_standards": [],
  "certification": [],
  "potential_gaps": [],
  "disclaimer": "..."
}
```

## 2. Tender analysis

POST `/api/tender/analyze`

Content-Type: `multipart/form-data`

Form field:

`file`: PDF or TXT tender document.

Response includes:

- `tender_analysis_id`
- `health_score`
- `summary`
- `findings`
- `extracted_text_preview`
- `analysis`

## 3. Standards

GET `/api/standards?q=water`

GET `/api/standards/{id}`

POST `/api/standards`

PUT `/api/standards/{id}`

DELETE `/api/standards/{id}`

The frontend should treat the backend as the source of truth for results.
