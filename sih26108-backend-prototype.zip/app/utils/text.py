import re

STOPWORDS = {
    "the","a","an","and","or","for","of","to","in","on","with","is","are",
    "we","need","required","requirement","procurement","supply","shall",
    "be","as","by","from","this","that","their","our"
}

def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower()).strip()

def tokens(text: str) -> list[str]:
    words = re.findall(r"[a-z0-9]+", normalize(text))
    return [w for w in words if w not in STOPWORDS and len(w) > 2]

def contains_any(text: str, terms: list[str]) -> bool:
    t = normalize(text)
    return any(term.lower() in t for term in terms)
