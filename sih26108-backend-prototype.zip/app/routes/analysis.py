import json
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Analysis
from ..schemas import AnalyzeRequest, AnalyzeResponse
from ..services.requirement_extractor import extract_requirements
from ..services.recommendation_engine import search_standards, expand_related, DISCLAIMER

router = APIRouter(prefix="/api", tags=["Analysis"])

@router.post("/analyze", response_model=AnalyzeResponse)
def analyze(req: AnalyzeRequest, db: Session = Depends(get_db)):
    extracted = extract_requirements(req.query)
    primary = search_standards(db, extracted, limit=5)
    allied = expand_related(db, primary[:2])

    testing = [x for x in allied if "test" in (x.title + x.category).lower()]
    safety = [x for x in allied if "safety" in (x.title + x.category).lower()]
    certification = []
    for x in primary + allied:
        if x.certification:
            certification.append(f"{x.is_number}: {x.certification}")

    gaps = []
    if not extracted.application:
        gaps.append("Intended application/use case is not explicit.")
    if not extracted.certification_requirements:
        gaps.append("Certification/conformity requirement is not explicitly stated; verify applicability.")
    if not testing:
        gaps.append("No testing standard was confidently discovered from the prototype relationship data.")
    if not extracted.safety_requirements:
        gaps.append("No explicit safety requirement detected in the input.")

    payload = {
        "requirements": extracted.model_dump(),
        "recommendations": [x.model_dump() for x in primary],
        "allied_standards": [x.model_dump() for x in allied],
        "testing_standards": [x.model_dump() for x in testing],
        "safety_standards": [x.model_dump() for x in safety],
        "certification": certification,
        "potential_gaps": gaps,
        "disclaimer": DISCLAIMER,
    }
    row = Analysis(query=req.query, result_json=json.dumps(payload))
    db.add(row)
    db.commit()
    db.refresh(row)

    return AnalyzeResponse(analysis_id=row.id, **payload)

@router.get("/analyses/{analysis_id}")
def get_analysis(analysis_id: int, db: Session = Depends(get_db)):
    row = db.get(Analysis, analysis_id)
    if not row:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Analysis not found")
    return {"analysis_id": row.id, "query": row.query, "result": json.loads(row.result_json), "created_at": row.created_at}
