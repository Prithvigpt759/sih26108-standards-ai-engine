from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Standard, StandardRelation
from ..schemas import StandardCreate, StandardUpdate, StandardOut

router = APIRouter(prefix="/api/standards", tags=["Standards"])

def out(db, s):
    rel = db.query(StandardRelation).filter(StandardRelation.source_is == s.is_number).all()
    return StandardOut(
        id=s.id, is_number=s.is_number, title=s.title, category=s.category,
        scope=s.scope, status=s.status, year=s.year, standard_type=s.standard_type,
        certification=s.certification, relations=[
            {"relation_type": r.relation_type, "is_number": r.target_is} for r in rel
        ]
    )

@router.get("", response_model=list[StandardOut])
def list_standards(
    q: str | None = Query(default=None),
    category: str | None = None,
    status: str | None = None,
    db: Session = Depends(get_db)
):
    query = db.query(Standard)
    if q:
        like = f"%{q}%"
        query = query.filter((Standard.title.ilike(like)) | (Standard.scope.ilike(like)) | (Standard.keywords.ilike(like)) | (Standard.is_number.ilike(like)))
    if category: query = query.filter(Standard.category.ilike(category))
    if status: query = query.filter(Standard.status.ilike(status))
    return [out(db, s) for s in query.order_by(Standard.id).all()]

@router.get("/{standard_id}", response_model=StandardOut)
def get_standard(standard_id: int, db: Session = Depends(get_db)):
    s = db.get(Standard, standard_id)
    if not s: raise HTTPException(404, "Standard not found")
    return out(db, s)

@router.post("", response_model=StandardOut, status_code=201)
def create_standard(data: StandardCreate, db: Session = Depends(get_db)):
    if db.query(Standard).filter(Standard.is_number == data.is_number).first():
        raise HTTPException(409, "IS number already exists")
    s = Standard(**data.model_dump())
    db.add(s); db.commit(); db.refresh(s)
    return out(db, s)

@router.put("/{standard_id}", response_model=StandardOut)
def update_standard(standard_id: int, data: StandardUpdate, db: Session = Depends(get_db)):
    s = db.get(Standard, standard_id)
    if not s: raise HTTPException(404, "Standard not found")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(s, k, v)
    db.commit(); db.refresh(s)
    return out(db, s)

@router.delete("/{standard_id}")
def delete_standard(standard_id: int, db: Session = Depends(get_db)):
    s = db.get(Standard, standard_id)
    if not s: raise HTTPException(404, "Standard not found")
    db.delete(s); db.commit()
    return {"message": "Standard deleted", "id": standard_id}
