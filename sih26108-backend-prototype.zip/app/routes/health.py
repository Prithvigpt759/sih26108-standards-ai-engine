from fastapi import APIRouter
router = APIRouter(tags=["Health"])

@router.get("/health")
def health():
    return {"status": "ok", "service": "SIH 26108 Standards Engine"}
