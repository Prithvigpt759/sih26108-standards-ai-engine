import json
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import TenderAnalysis
from ..services.tender_analyzer import analyze_tender_text
from ..services.recommendation_engine import DISCLAIMER

router = APIRouter(prefix="/api/tender", tags=["Tender"])

@router.post("/analyze")
async def analyze_tender(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    if not file.filename:
        raise HTTPException(400, "Filename is required")
    content = await file.read()
    if len(content) > 10 * 1024 * 1024:
        raise HTTPException(413, "File is larger than 10 MB")

    text = ""
    if file.filename.lower().endswith(".txt"):
        text = content.decode("utf-8", errors="ignore")
    elif file.filename.lower().endswith(".pdf"):
        try:
            import fitz
            doc = fitz.open(stream=content, filetype="pdf")
            text = "\n".join(page.get_text() for page in doc)
        except Exception as e:
            raise HTTPException(400, f"Could not read PDF: {e}")
    else:
        raise HTTPException(400, "Prototype accepts PDF or TXT files")

    score, result = analyze_tender_text(db, file.filename, text)
    row = TenderAnalysis(filename=file.filename, health_score=score, result_json=json.dumps(result))
    db.add(row); db.commit(); db.refresh(row)

    return {
        "tender_analysis_id": row.id,
        "filename": file.filename,
        "health_score": score,
        "summary": result["summary"],
        "findings": result["findings"],
        "extracted_text_preview": result["text_preview"],
        "analysis": result,
        "disclaimer": DISCLAIMER
    }

@router.get("/{tender_analysis_id}")
def get_tender_analysis(tender_analysis_id: int, db: Session = Depends(get_db)):
    row = db.get(TenderAnalysis, tender_analysis_id)
    if not row: raise HTTPException(404, "Tender analysis not found")
    return {
        "tender_analysis_id": row.id,
        "filename": row.filename,
        "health_score": row.health_score,
        "result": json.loads(row.result_json),
        "created_at": row.created_at
    }
