from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings, cors_list
from .database import Base, engine, SessionLocal
from .routes import health, analysis, standards, tender
from .seed import seed_database

Base.metadata.create_all(bind=engine)
seed_database()

app = FastAPI(
    title=settings.app_name,
    version="0.1.0",
    description="Prototype backend for AI-powered Indian Standards recommendation and tender health analysis."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_list(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(analysis.router)
app.include_router(standards.router)
app.include_router(tender.router)

@app.get("/")
def root():
    return {
        "message": "SIH 26108 AI Standards Engine API",
        "docs": "/docs",
        "health": "/health"
    }
