from typing import Any
from pydantic import BaseModel, Field

class AnalyzeRequest(BaseModel):
    query: str = Field(min_length=3, max_length=10000)

class RequirementExtraction(BaseModel):
    product: str | None = None
    material: str | None = None
    capacity: str | None = None
    application: str | None = None
    quantity: str | None = None
    performance_requirements: list[str] = []
    safety_requirements: list[str] = []
    certification_requirements: list[str] = []
    keywords: list[str] = []

class StandardOut(BaseModel):
    id: int
    is_number: str
    title: str
    category: str
    scope: str
    status: str
    year: int | None
    standard_type: str
    certification: str | None
    relevance_score: float | None = None
    classification: str | None = None
    why: list[str] = []
    relations: list[dict[str, str]] = []

    class Config:
        from_attributes = True

class AnalyzeResponse(BaseModel):
    analysis_id: int
    requirements: RequirementExtraction
    recommendations: list[StandardOut]
    allied_standards: list[StandardOut]
    testing_standards: list[StandardOut]
    safety_standards: list[StandardOut]
    certification: list[str]
    potential_gaps: list[str]
    disclaimer: str

class TenderHealthResponse(BaseModel):
    tender_analysis_id: int
    filename: str
    health_score: float
    summary: dict[str, Any]
    findings: list[dict[str, Any]]
    extracted_text_preview: str
    disclaimer: str

class StandardCreate(BaseModel):
    is_number: str
    title: str
    category: str
    scope: str
    status: str = "CURRENT"
    year: int | None = None
    standard_type: str = "Product"
    certification: str | None = None
    keywords: str = ""
    notes: str | None = None

class StandardUpdate(BaseModel):
    title: str | None = None
    category: str | None = None
    scope: str | None = None
    status: str | None = None
    year: int | None = None
    standard_type: str | None = None
    certification: str | None = None
    keywords: str | None = None
    notes: str | None = None
