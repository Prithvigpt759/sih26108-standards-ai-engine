from datetime import datetime
from sqlalchemy import String, Text, Integer, Boolean, DateTime, Float
from sqlalchemy.orm import Mapped, mapped_column
from .database import Base

class Standard(Base):
    __tablename__ = "standards"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    is_number: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(500))
    category: Mapped[str] = mapped_column(String(200), index=True)
    scope: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(50), default="CURRENT")
    year: Mapped[int | None] = mapped_column(Integer, nullable=True)
    standard_type: Mapped[str] = mapped_column(String(100), default="Product")
    certification: Mapped[str | None] = mapped_column(Text, nullable=True)
    keywords: Mapped[str] = mapped_column(Text, default="")
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

class StandardRelation(Base):
    __tablename__ = "standard_relations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_is: Mapped[str] = mapped_column(String(100), index=True)
    target_is: Mapped[str] = mapped_column(String(100), index=True)
    relation_type: Mapped[str] = mapped_column(String(80), index=True)

class Analysis(Base):
    __tablename__ = "analyses"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    query: Mapped[str] = mapped_column(Text)
    result_json: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class TenderAnalysis(Base):
    __tablename__ = "tender_analyses"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    filename: Mapped[str] = mapped_column(String(500))
    health_score: Mapped[float] = mapped_column(Float)
    result_json: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
