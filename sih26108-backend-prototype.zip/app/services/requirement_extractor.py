import re
from ..schemas import RequirementExtraction
from ..utils.text import tokens

PRODUCT_PATTERNS = [
    (r"\bwater\s+storage\s+tank(s)?\b", "Water storage tank"),
    (r"\bwater\s+tank(s)?\b", "Water tank"),
    (r"\bpump(s)?\b", "Pump"),
    (r"\belectric(al)?\s+cable(s)?\b", "Electrical cable"),
    (r"\bsteel\s+pipe(s)?\b", "Steel pipe"),
    (r"\bcement\b", "Cement"),
    (r"\bhelmet(s)?\b|\bsafety\s+helmet(s)?\b", "Safety helmet"),
]

def extract_requirements(text: str) -> RequirementExtraction:
    low = text.lower()

    product = None
    for pattern, label in PRODUCT_PATTERNS:
        if re.search(pattern, low):
            product = label
            break

    material = None
    for m in ["stainless steel", "steel", "concrete", "plastic", "hdpe", "pvc", "aluminium", "aluminum", "copper"]:
        if m in low:
            material = m
            break

    capacity = None
    m = re.search(r"(\d+(?:\.\d+)?)\s*(litre|liter|litres|liters|l)\b", low)
    if m:
        capacity = f"{m.group(1)} litre"

    quantity = None
    m = re.search(r"\b(\d[\d,]*)\s+(?:units?|pieces?|nos?|tanks?|pumps?|cables?)\b", low)
    if m:
        quantity = m.group(1)

    application = None
    if any(x in low for x in ["potable", "drinking water"]):
        application = "Potable water"
    elif "industrial" in low:
        application = "Industrial"
    elif "domestic" in low:
        application = "Domestic"
    elif "construction" in low:
        application = "Construction"

    safety = []
    if any(x in low for x in ["safety", "safe", "hazard"]):
        safety.append("Safety requirements mentioned in procurement text")

    certification = []
    if any(x in low for x in ["bis", "certification", "certified", "isi mark", "crs"]):
        certification.append("Certification requirement mentioned by purchaser")

    performance = []
    if capacity:
        performance.append(f"Capacity: {capacity}")

    return RequirementExtraction(
        product=product,
        material=material,
        capacity=capacity,
        application=application,
        quantity=quantity,
        performance_requirements=performance,
        safety_requirements=safety,
        certification_requirements=certification,
        keywords=tokens(text)[:25],
    )
