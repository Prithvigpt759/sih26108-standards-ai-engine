import re
from .requirement_extractor import extract_requirements
from .recommendation_engine import search_standards, expand_related
from ..schemas import TenderHealthResponse

def analyze_tender_text(db, filename, text):
    req = extract_requirements(text)
    primary = search_standards(db, req, limit=5)
    allied = expand_related(db, primary[:2])

    findings = []
    score = 100

    if not req.product:
        findings.append({"severity":"HIGH","type":"Missing product","message":"Product/category could not be confidently identified."})
        score -= 20

    if not req.application:
        findings.append({"severity":"MEDIUM","type":"Missing application","message":"Intended application/use case is not explicit."})
        score -= 10

    if not primary:
        findings.append({"severity":"HIGH","type":"Standards coverage","message":"No matching standards found in prototype dataset."})
        score -= 25

    if not re.search(r"\btest(ing)?\b|\binspection\b|\bacceptance\b", text, re.I):
        findings.append({"severity":"MEDIUM","type":"Testing clause","message":"Tender text does not clearly specify testing/inspection requirements."})
        score -= 10

    if not re.search(r"\b(certif|bis|isi|conformity)\w*\b", text, re.I):
        findings.append({"severity":"MEDIUM","type":"Certification","message":"No explicit certification/conformity language detected; verify applicability."})
        score -= 8

    if re.search(r"\binstallation\b", text, re.I) is None:
        findings.append({"severity":"LOW","type":"Installation","message":"Installation requirements are not explicitly detected."})
        score -= 5

    current_refs = len(re.findall(r"\bIS\s*[:\-]?\s*\d+\b", text, re.I))
    if current_refs == 0:
        findings.append({"severity":"LOW","type":"Standard references","message":"No explicit IS-number references detected in uploaded text."})
        score -= 5

    score = max(0, min(100, score))
    return score, {
        "requirements": req.model_dump(),
        "primary_recommendations": [x.model_dump() for x in primary],
        "allied_standards": [x.model_dump() for x in allied],
        "findings": findings,
        "summary": {
            "health_score": score,
            "standards_found": len(primary),
            "allied_standards_found": len(allied),
            "issues_detected": len(findings),
        },
        "text_preview": re.sub(r"\s+", " ", text).strip()[:1500]
    }
