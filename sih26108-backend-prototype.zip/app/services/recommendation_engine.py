from sqlalchemy.orm import Session
from ..models import Standard, StandardRelation
from ..schemas import RequirementExtraction, StandardOut
from ..utils.text import normalize, tokens

DISCLAIMER = (
    "Prototype recommendation only. Always verify the latest official BIS publication, "
    "amendments, applicable Quality Control Orders and certification scheme before procurement."
)

def _score(req: RequirementExtraction, std: Standard):
    query_parts = [
        req.product or "", req.material or "", req.application or "",
        req.capacity or "", " ".join(req.keywords)
    ]
    q = set(tokens(" ".join(query_parts)))
    doc = set(tokens(" ".join([
        std.title, std.category, std.scope, std.keywords, std.standard_type
    ])))
    overlap = len(q & doc) / max(1, len(q))
    exact = 0
    combined = normalize(" ".join(query_parts))
    title_scope = normalize(std.title + " " + std.scope + " " + std.category)
    if req.product and normalize(req.product) in title_scope: exact += 0.30
    if req.material and normalize(req.material) in title_scope: exact += 0.15
    if req.application and normalize(req.application) in title_scope: exact += 0.15
    score = min(1.0, 0.40 * overlap + exact + (0.10 if std.status == "CURRENT" else 0))
    return round(score, 3)

def _relations(db: Session, is_number: str):
    rows = db.query(StandardRelation).filter(StandardRelation.source_is == is_number).all()
    return [{"relation_type": r.relation_type, "is_number": r.target_is} for r in rows]

def _why(req, std):
    reasons = []
    hay = normalize(std.title + " " + std.scope + " " + std.category + " " + std.keywords)
    if req.product and normalize(req.product) in hay: reasons.append("Product category matches")
    if req.material and normalize(req.material) in hay: reasons.append("Material is relevant")
    if req.application and normalize(req.application) in hay: reasons.append("Application matches")
    if std.status == "CURRENT": reasons.append("Record is marked current in prototype dataset")
    if not reasons: reasons.append("Semantic/keyword overlap with procurement requirement")
    return reasons

def search_standards(db: Session, req: RequirementExtraction, limit=5):
    standards = db.query(Standard).all()
    ranked = sorted(standards, key=lambda s: _score(req, s), reverse=True)
    out = []
    for s in ranked[:limit]:
        score = _score(req, s)
        classification = "PRIMARY" if score >= 0.45 else "RELATED"
        out.append(StandardOut(
            id=s.id, is_number=s.is_number, title=s.title, category=s.category,
            scope=s.scope, status=s.status, year=s.year, standard_type=s.standard_type,
            certification=s.certification, relevance_score=score,
            classification=classification, why=_why(req, s),
            relations=_relations(db, s.is_number)
        ))
    return out

def expand_related(db: Session, primary):
    if not primary:
        return []
    is_numbers = {x.is_number for x in primary}
    targets = []
    for s in primary:
        for rel in _relations(db, s.is_number):
            if rel["is_number"] not in is_numbers:
                targets.append(rel["is_number"])
    if not targets:
        return []
    rows = db.query(Standard).filter(Standard.is_number.in_(targets)).all()
    return [
        StandardOut(
            id=s.id, is_number=s.is_number, title=s.title, category=s.category,
            scope=s.scope, status=s.status, year=s.year, standard_type=s.standard_type,
            certification=s.certification, relevance_score=None,
            classification="ALLIED", why=["Discovered through standards relationship graph"],
            relations=_relations(db, s.is_number)
        ) for s in rows
    ]
