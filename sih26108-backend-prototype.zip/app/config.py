from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "SIH 26108 AI Standards Engine"
    database_url: str = "sqlite:///./sih26108.db"
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000"
    max_upload_mb: int = 10

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()

def cors_list():
    return [x.strip() for x in settings.cors_origins.split(",") if x.strip()]
