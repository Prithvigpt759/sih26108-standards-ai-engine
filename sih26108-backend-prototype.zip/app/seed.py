import json
from pathlib import Path
from sqlalchemy import select
from .database import SessionLocal
from .models import Standard, StandardRelation

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT.parent / "data"

def seed_database():
    db = SessionLocal()
    try:
        if db.execute(select(Standard)).first() is None:
            standards = json.loads((DATA / "standards.json").read_text(encoding="utf-8"))
            db.add_all([Standard(**s) for s in standards])
            db.commit()

        if db.execute(select(StandardRelation)).first() is None:
            relations = json.loads((DATA / "relations.json").read_text(encoding="utf-8"))
            db.add_all([StandardRelation(**r) for r in relations])
            db.commit()
    finally:
        db.close()
